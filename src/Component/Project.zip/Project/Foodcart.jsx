
import React from 'react'
import Layout from './Layout'
import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material'

  const Foodcart = () => {
  return (
     <Layout>
     <Box>
         <TableContainer component={Paper}>
           <Table sx={{ }} aria-label="simple table">
             <TableHead>
               <TableRow>
                 <TableCell>SN</TableCell>
                 <TableCell>Menu</TableCell>
                 <TableCell>Qty</TableCell>
                 <TableCell>Price</TableCell>
               </TableRow>
             </TableHead>
             <TableBody>
             <TableRow>
             <TableCell>
              1: 
             </TableCell>
             <TableCell>
              1: 
             </TableCell>
             </TableRow>
             <TableRow>
             <TableCell>
              1: 
             </TableCell>
             <TableCell>
              1: 
             </TableCell>
             </TableRow>
             
              <TableRow>
             <TableCell>
              1: 
              </TableCell>
             </TableRow>
             <TableRow>
             <TableCell>
              2:
             </TableCell>
             </TableRow>
             <TableRow>
             <TableCell>
              3:
             </TableCell>
             </TableRow>
             </TableBody>
           </Table>
         </TableContainer>
       
     
     
      
     
     </Box>
     
     
     </Layout>
  )
}

export default Foodcart
