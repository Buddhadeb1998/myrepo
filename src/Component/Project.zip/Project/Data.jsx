//  import nonveg1 from '../../Component/images/nonveg1.jpg'
 import nonveg1 from '../images/nonveg1.jpg'
 import nonveg2 from '../images/nonveg2.jpg'
 import nonveg3 from '../images/nonveg3.jpg'
 import Dosa from '../images/Dosa.jpg'
 import idly from '../images/idly.jpg'
 import Uttapam from '../images/Uttapam.jpg'

 
 const Data=[
    {
        id:'menu1',
        name:'chicken',
        image: nonveg1,
        price:100,
        quantity:0
    },
    {
        id:'menu2',
        name:'chicken',
        image: nonveg2,
        price:100,
        quantity:0
    },
    {
        id:'menu3',
        name:'chicken',
        image: nonveg3,
        price:100,
        quantity:0
    },
    {
        id:'menu4',
        name:'Dosa',
        image: Dosa,
        price:100,
        quantity:0
    },
    {
        id:'menu5',
        name:'Idly',
        image: idly,
        price:100,
        quantity:0
    },
    {
        id:'menu6',
        name:'Uttapam',
        image: Uttapam,
        price:100,
        quantity:0
    },
 ]
 export default Data